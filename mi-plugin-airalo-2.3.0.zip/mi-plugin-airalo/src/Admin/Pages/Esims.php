<?php
/**
 * Admin page: eSIMs list (with usage).
 *
 * @package Hugo\MiPluginAiralo
 */

namespace Hugo\MiPluginAiralo\Admin\Pages;

use Hugo\MiPluginAiralo\Api\Client;
use Hugo\MiPluginAiralo\Api\Exception;
use Hugo\MiPluginAiralo\Plugin;
use Hugo\MiPluginAiralo\Support\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Esims {

    public function __construct(
        private readonly Client $api,
        private readonly Logger $logger
    ) {
    }

    public function register(): void {}

    public function render(): void {
        if ( ! current_user_can( Plugin::instance()->capability() ) ) {
            wp_die( esc_html__( 'Permisos insuficientes.', MPA_TEXTDOMAIN ) );
        }

        $search = sanitize_text_field( (string) ( $_GET['s'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $sims   = [];
        $error  = null;
        $loaded = 0;
        $notice = null;

        if ( $this->api->is_configured() ) {
            try {
                $sims   = $this->load_sim_index();
                $loaded = count( $sims );

                if ( '' !== $search ) {
                    $needle = strtolower( $search );
                    $sims   = array_values( array_filter( $sims, static function ( $s ) use ( $needle ) {
                        return strpos( strtolower( (string) ( $s['iccid'] ?? '' ) ), $needle ) !== false;
                    } ) );

                    if ( empty( $sims ) && preg_match( '/^\d{16,22}$/', $search ) ) {
                        $rows = $this->api->search_sims_by_iccid( $search );
                        if ( ! empty( $rows ) ) {
                            $sims = array_map( [ $this, 'normalize_sim' ], $rows );
                            if ( (bool) ( $sims[0]['_recycled'] ?? false ) ) {
                                $recycled_at = (string) ( $sims[0]['_recycled_at'] ?? '' );
                                $notice      = sprintf(
                                    /* translators: 1: ICCID, 2: recycled-at date */
                                    __( 'eSIM %1$s encontrada pero está expirada (reciclada el %2$s).', MPA_TEXTDOMAIN ),
                                    $search,
                                    $recycled_at ? $recycled_at : '—'
                                );
                            } else {
                                $notice = sprintf(
                                    /* translators: %s: ICCID */
                                    __( 'eSIM %s encontrada vía búsqueda directa en Airalo.', MPA_TEXTDOMAIN ),
                                    $search
                                );
                            }
                        } elseif ( '' !== $search ) {
                            $notice = sprintf(
                                /* translators: %s: searched ICCID */
                                __( 'No se encontró ninguna eSIM con ICCID %s en tu cuenta Airalo.', MPA_TEXTDOMAIN ),
                                $search
                            );
                        }
                    } elseif ( '' !== $search && empty( $sims ) ) {
                        $notice = sprintf(
                            /* translators: %s: search query */
                            __( 'No hay coincidencias para "%s" en el índice local. Si la eSIM está expirada prueba con la búsqueda directa (ya integrada) o con la ICCID completa.', MPA_TEXTDOMAIN ),
                            $search
                        );
                    }
                }
            } catch ( Exception $e ) {
                $error = $e->getMessage();
                $this->logger->warning( 'eSIMs list: ' . $e->getMessage() );
            }
        }

        ?>
        <div class="wrap mpa-wrap">
            <h1><?php esc_html_e( 'Airalo · eSIMs', MPA_TEXTDOMAIN ); ?></h1>

            <form method="get" class="mpa-search">
                <input type="hidden" name="page" value="mpa-esims" />
                <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Buscar por ICCID', MPA_TEXTDOMAIN ); ?>" />
                <?php submit_button( __( 'Buscar', MPA_TEXTDOMAIN ), 'secondary', '', false ); ?>
                <?php if ( '' !== $search ) : ?>
                    <a class="button button-link" href="<?php echo esc_url( remove_query_arg( 's' ) ); ?>"><?php esc_html_e( 'Limpiar', MPA_TEXTDOMAIN ); ?></a>
                <?php endif; ?>
            </form>

            <p class="description">
                <?php
                /* translators: %d: number of eSIMs indexed */
                echo esc_html( sprintf( _n( 'Índice: %d eSIM', 'Índice: %d eSIMs', $loaded, MPA_TEXTDOMAIN ), $loaded ) );
                ?>
                <span style="margin-left:8px;color:#8c8f94;"><?php esc_html_e( 'La búsqueda funciona por ICCID exacta (incluye eSIMs expiradas).', MPA_TEXTDOMAIN ); ?></span>
            </p>

            <?php if ( $error ) : ?>
                <div class="notice notice-error inline"><p><?php echo esc_html( $error ); ?></p></div>
            <?php endif; ?>

            <?php if ( $notice ) :
                $cls = str_contains( strtolower( $notice ), 'expirada' ) || str_contains( strtolower( $notice ), 'no se encontró' ) ? 'notice-warning' : 'notice-info';
                ?>
                <div class="notice <?php echo esc_attr( $cls ); ?> inline"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>

            <?php $this->render_table( $sims ); ?>
        </div>
        <?php
    }

    /**
     * Builds a flat list of every eSIM in the account.
     *
     * Uses `GET /v2/sims` (not `/v2/orders`) so that recycled / expired
     * eSIMs are included in the index and can be looked up. The list is
     * cached for 5 min.
     *
     * @return array<int, array<string,mixed>>
     */
    private function load_sim_index(): array {
        $cache_key = 'mpa_sim_index_v2';
        $cached    = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $rows  = $this->api->get_sims_paginated( [], 30, 100 );
        $sims  = [];
        foreach ( (array) $rows as $row ) {
            $sims[] = $this->normalize_sim( $row );
        }

        set_transient( $cache_key, $sims, 5 * MINUTE_IN_SECONDS );
        return $sims;
    }

    /**
     * Maps a raw `GET /v2/sims` row to the internal shape used by the table.
     * Handles both the with-`include=order,order.user` envelope and the
     * flat single-sim endpoint responses.
     */
    private function normalize_sim( array $row ): array {
        $order = (array) ( $row['order'] ?? [] );
        $user  = (array) ( $row['user'] ?? $order['user'] ?? [] );
        $status = (array) ( $order['status'] ?? [] );

        $row['_order_code']  = (string) ( $order['code'] ?? $row['code'] ?? '' );
        $row['_package_id']  = (string) ( $row['package_id'] ?? $order['package_id'] ?? '' );
        $row['_package']     = (string) ( $order['package'] ?? $row['package'] ?? '' );
        $row['_created_at']  = (string) ( $row['created_at'] ?? $order['created_at'] ?? '' );
        $row['_description'] = (string) ( $order['description'] ?? '' );
        $row['_user']        = $user;
        $row['_status']      = $status;
        $row['_recycled']    = (bool) ( $row['recycled'] ?? false );
        $row['_recycled_at'] = (string) ( $row['recycled_at'] ?? '' );
        return $row;
    }

    private function render_table( array $sims ): void {
        if ( empty( $sims ) ) {
            echo '<p>' . esc_html__( 'No hay eSIMs para mostrar.', MPA_TEXTDOMAIN ) . '</p>';
            return;
        }
        ?>
        <table class="widefat striped mpa-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'ICCID', MPA_TEXTDOMAIN ); ?></th>
                    <th><?php esc_html_e( 'Estado', MPA_TEXTDOMAIN ); ?></th>
                    <th><?php esc_html_e( 'Usuario', MPA_TEXTDOMAIN ); ?></th>
                    <th><?php esc_html_e( 'País', MPA_TEXTDOMAIN ); ?></th>
                    <th><?php esc_html_e( 'Paquete', MPA_TEXTDOMAIN ); ?></th>
                    <th><?php esc_html_e( 'Código', MPA_TEXTDOMAIN ); ?></th>
                    <th><?php esc_html_e( 'Creada', MPA_TEXTDOMAIN ); ?></th>
                    <th><?php esc_html_e( 'Acciones', MPA_TEXTDOMAIN ); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ( $sims as $sim ) :
                $iccid  = (string) ( $sim['iccid'] ?? '' );
                if ( '' === $iccid ) {
                    continue;
                }
                $detail_url = add_query_arg(
                    [ 'page' => 'mpa-esim-detail', 'iccid' => $iccid ],
                    admin_url( 'admin.php' )
                );
                $user_label = $this->get_esim_user( $sim );
                $country    = $this->api->get_country_for_package( (string) ( $sim['_package_id'] ?? '' ) );
                $recycled   = (bool) ( $sim['_recycled'] ?? false );
                $status     = $sim['_status'] ?? [];
                $status_lbl = (string) ( $status['name'] ?? $status['slug'] ?? '' );
            ?>
                <tr <?php echo $recycled ? 'style="background:#fff8e1;"' : ''; ?>>
                    <td><a href="<?php echo esc_url( $detail_url ); ?>"><code><?php echo esc_html( $iccid ); ?></code></a></td>
                    <td>
                        <?php if ( $recycled ) : ?>
                            <span class="mpa-pill mpa-pill--warning" title="<?php echo esc_attr( (string) ( $sim['_recycled_at'] ?? '' ) ); ?>"><?php esc_html_e( 'Expirada', MPA_TEXTDOMAIN ); ?></span>
                        <?php elseif ( '' !== $status_lbl ) : ?>
                            <span class="mpa-pill mpa-pill--ok"><?php echo esc_html( $status_lbl ); ?></span>
                        <?php else : ?>
                            <span style="color:#8c8f94;">—</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo '' !== $user_label ? esc_html( $user_label ) : '<span style="color:#8c8f94;">—</span>'; ?></td>
                    <td><?php echo '' !== $country ? '<span class="mpa-pill mpa-pill--country">' . esc_html( $country ) . '</span>' : '<span style="color:#8c8f94;">—</span>'; ?></td>
                    <td>
                        <?php echo esc_html( (string) ( $sim['_package'] ?? $sim['_package_id'] ?? '' ) ); ?>
                        <?php if ( ! empty( $sim['_package'] ) && ! empty( $sim['_package_id'] ) && $sim['_package'] !== $sim['_package_id'] ) : ?>
                            <br><code class="mpa-mono"><?php echo esc_html( (string) $sim['_package_id'] ); ?></code>
                        <?php endif; ?>
                    </td>
                    <td><?php echo esc_html( (string) ( $sim['_order_code'] ?? '' ) ); ?></td>
                    <td><?php echo esc_html( (string) ( $sim['_created_at'] ?? '' ) ); ?></td>
                    <td>
                        <div class="mpa-action-stack" style="display:flex;gap:4px;flex-wrap:wrap;">
                            <a class="button button-small" href="<?php echo esc_url( $detail_url ); ?>"><?php esc_html_e( 'Detalle', MPA_TEXTDOMAIN ); ?></a>
                            <?php if ( ! $recycled ) : ?>
                                <button type="button" class="button button-small mpa-action" data-action="mpa_get_usage" data-iccid="<?php echo esc_attr( $iccid ); ?>"><?php esc_html_e( 'Uso', MPA_TEXTDOMAIN ); ?></button>
                                <button type="button" class="button button-small mpa-action" data-action="mpa_refund_esim" data-iccid="<?php echo esc_attr( $iccid ); ?>"><?php esc_html_e( 'Refund', MPA_TEXTDOMAIN ); ?></button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    /**
     * Returns the eSIM User label. Prefers the live `simable.user` from
     * Airalo; falls back to the WC order billing name parsed from the
     * `WC#N` token in the order description.
     */
    private function get_esim_user( array $sim ): string {
        $airalo_user = $sim['_user'] ?? [];
        if ( is_array( $airalo_user ) && ( ! empty( $airalo_user['name'] ) || ! empty( $airalo_user['email'] ) ) ) {
            $name  = (string) ( $airalo_user['name'] ?? '' );
            $email = (string) ( $airalo_user['email'] ?? '' );
            return trim( $name ) ? "$name ($email)" : $email;
        }

        $description = (string) ( $sim['_description'] ?? '' );
        if ( $description && preg_match( '/WC#(\d+)/', $description, $m ) ) {
            $wc_order = wc_get_order( (int) $m[1] );
            if ( $wc_order ) {
                $name  = trim( (string) $wc_order->get_billing_first_name() . ' ' . $wc_order->get_billing_last_name() );
                $email = (string) $wc_order->get_billing_email();
                return trim( $name ) ? "$name ($email)" : $email;
            }
        }
        return '';
    }
}
